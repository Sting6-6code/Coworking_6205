package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import util.CurrentUser;

import java.io.*;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private TextField passwordField;
    @FXML private Button loginButton;
    @FXML private Button registerButton;

    private static final String DATA_FILE = "src/application/data.csv";

    @FXML
    private void login() {
        String usernameInput = usernameField.getText().trim();
        String passwordInput = passwordField.getText().trim();

        if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
            showAlert("Error", "Please enter both username and password!");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(DATA_FILE))) {
            String line;
            br.readLine(); // 跳过表头

            boolean found = false;

            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 6) {
                    String userId = fields[0];
                    String username = fields[1];
                    String password = fields[2];
                    String email = fields[3];
                    String type = fields[4];
                    String membership = fields[5];

                    if (username.equals(usernameInput) && password.equals(passwordInput)) {
                        found = true;
                        UserController.setCurrentUser(username);
                        AdminController.setCurrentAdmin(username);
                        BookingController.setCurrentUser(username);
                        UsersController.setCurrentUser(username);
                        // 设置当前用户，确保 userId 可用
                        CurrentUser.setCurrentUser(userId, username, type, email, membership);

                        // 根据类型跳转界面
                        FXMLLoader loader = new FXMLLoader(getClass().getResource(
                                type.equalsIgnoreCase("Admin") ? "admin.fxml" : "user.fxml"
                        ));
                        Scene scene = new Scene(loader.load(), 600, 400);
                        Stage stage = (Stage) loginButton.getScene().getWindow();
                        stage.setScene(scene);
                        return;
                    }
                }
            }

            if (!found) {
                showAlert("Error", "Invalid username or password!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Login failed due to an unexpected error.");
        }
    }

    @FXML
    private void goToRegister() {
        try {
            Main.changeScene("register.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
