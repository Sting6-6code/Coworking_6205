package util;

public class CurrentUser {
    private static String userId;
    private static String username;
    private static String type;
    private static String email;
    private static String membership;

    public static void setCurrentUser(String userId, String username, String type, String email, String membership) {
        CurrentUser.userId = userId;
        CurrentUser.username = username;
        CurrentUser.type = type;
        CurrentUser.email = email;
        CurrentUser.membership = membership;
    }

    public static String getUserId() { return userId; }
    public static String getUsername() { return username; }
    public static String getType() { return type; }
    public static String getEmail() { return email; }
    public static String getMembership() { return membership; }
}
